CREATE DATABASE IF NOT EXISTS watch_catalog
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE watch_catalog;

CREATE TABLE IF NOT EXISTS products (
    id          INT UNSIGNED    AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(150)    NOT NULL,
    description TEXT            NOT NULL,
    price       DECIMAL(10, 2)  NOT NULL,
    image       LONGTEXT            NOT NULL,
    created_at  TIMESTAMP       DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

ALTER TABLE products 
MODIFY image LONGTEXT NOT NULL;

-- Clear old data
TRUNCATE TABLE products;

-- Fresh seed data with light background watch images
INSERT INTO products (name, description, price, image) VALUES

('Rolex GMT-Master II', 'The traveler\'s companion featuring a dual-time zone display, iconic two-tone ceramic bezel, and a 24-hour hand. Precision-engineered in Oystersteel for the modern globetrotter.', 15800.00, 'https://images.unsplash.com/photo-1639006570490-79c0c53f1080?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Rolex Daytona', 'The racing legend. A self-winding chronograph with tachymetric scale, three contrasting subdials, and a column-wheel mechanism. Housed in polished Oystersteel with an Oyster bracelet.', 29500.00, 'https://images.unsplash.com/photo-1671119720870-df45dcaf81c1?q=80&w=755&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Omega Speedmaster Moonwatch', 'The first watch worn on the moon in 1969. Manual-winding chronograph, hesalite crystal, black dial with tachymeter bezel, and a stainless steel case on a vintage-style bracelet.', 6400.00, 'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?q=80&w=1480&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Omega Seamaster Planet Ocean', 'A professional diver rated to 600m, featuring a co-axial master chronometer movement, helium escape valve, and liquid metal bezel. Bold orange accents on a deep black dial.', 7200.00, 'https://images.unsplash.com/photo-1773755060442-6d128b70dd20?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Audemars Piguet Royal Oak Offshore', 'The rugged evolution of the Royal Oak. An oversized 42mm case, mega tapisserie dial, rubber-clad pushers, and a certified chronograph movement — luxury redefined for adventure.', 42000.00, 'https://images.unsplash.com/photo-1626624386327-5204714bae9f?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Patek Philippe Aquanaut', 'A contemporary sports watch with an embossed tropical dial, rounded octagonal bezel, and a composite strap. Houses an ultra-reliable automatic movement in a 40mm steel case.', 32000.00, 'https://images.unsplash.com/photo-1600897425543-5369a38bd193?q=80&w=2103&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Patrek Philippe ILYODES King Slayer', 'Built for the Ily00des , worn everywhere.  when he was an a date with ouissem . Precise, legible, and functional.', 44000.00, 'https://images.unsplash.com/photo-1600003014608-c2ccc1570a65?q=80&w=680&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Cartier SALIM IV', 'The square-cased icon immortalized by Steve McQueen in 1971. Blue dial with white subdials, date window, and an automatic calibre 11 movement in a polished steel square case.', 5800.00, 'https://images.unsplash.com/photo-1747995525906-b141498b8e7e?q=80&w=694&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Breitling Superocean Heritage', 'Classic 1950s diving aesthetics with modern internals. Features a COSC-certified movement, vintage-style bezel, luminescent dial, and 200m water resistance on a brown leather strap.', 4900.00, 'https://images.unsplash.com/photo-1639564879163-a2a85682410e?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Casio Mouminito', 'Pure Italian military design. A slim wire-lug cushion case, hand-wound movement, clean black dial with oversized Arabic numerals, and a vintage tobacco leather strap. Power reserve of 3 days.', 9800.00, 'https://images.unsplash.com/photo-1577993944451-f8618a835822?q=80&w=706&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Cartier Tank Must', 'An art deco masterpiece reborn. Rectangular case, Roman numeral chapter ring, blued sword hands, sapphire cabochon crown, and a bordeaux alligator strap. Quartz precision in timeless form.', 3200.00, 'https://images.unsplash.com/photo-1581063683670-6df2247f1d8e?q=80&w=880&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Hublot Classic Fusion', 'Where tradition meets innovation. A 42mm polished titanium case, skeleton dial revealing the automatic movement, and a black rubber strap with a satin-finished titanium deployant clasp.', 11000.00, 'https://images.unsplash.com/photo-1638872726305-35e2e39fb154?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Tudor Pelagos', 'Tudor\'s professional dive watch with a 500m rating, titanium case and bracelet, ceramic bezel insert, and a self-winding movement with a variable-inertia balance. Functional, rugged, and refined.', 4200.00, 'https://images.unsplash.com/photo-1697809653305-aa9799a495c2?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'),

('Zenith Defy Classic', 'High-frequency open-heart elegance. Features the El Primero calibre beating at 36,000 vph, a skeletonized dial with three-color subdials, and a 41mm polished steel case on an integrated bracelet.', 7600.00, 'https://images.unsplash.com/photo-1653777682069-2082283280db?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')