from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
import os
import base64

app = Flask(__name__)
CORS(app)

# ── DB config ──────────────────────────────────────────────────────────────
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "salim2004salim",  
    "database": "watch_catalog",
}

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/api/products", methods=["GET"])
def get_products():
    search = request.args.get("search", "").strip()
    try:
        conn = get_db()
        cursor = conn.cursor(dictionary=True)
        if search:
            # Products whose name starts with search term come first
            cursor.execute(
                """
                SELECT id, name, description, price, image
                FROM products
                ORDER BY
                    CASE WHEN name LIKE %s THEN 0 ELSE 1 END,
                    name
                """,
                (f"{search}%",),
            )
        else:
            cursor.execute("SELECT id, name, description, price, image FROM products ORDER BY id DESC")
        products = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify({"products": products}), 200
    except mysql.connector.Error as e:
        return jsonify({"error": f"Database error: {str(e)}"}), 500


@app.route("/api/products", methods=["POST"])
def add_product():
    data = request.get_json()

    # ── Validation ────────────────────────────────────────────────────────
    errors = {}
    name = (data.get("name") or "").strip()
    description = (data.get("description") or "").strip()
    price_raw = data.get("price")
    image = (data.get("image") or "").strip()

    if not name:
        errors["name"] = "Product name is required."
    elif len(name) > 150:
        errors["name"] = "Name must be 150 characters or fewer."

    if not description:
        errors["description"] = "Description is required."
    elif len(description) > 1000:
        errors["description"] = "Description must be 1000 characters or fewer."

    if price_raw is None or str(price_raw).strip() == "":
        errors["price"] = "Price is required."
    else:
        try:
            price = float(price_raw)
            if price <= 0:
                errors["price"] = "Price must be a positive number."
            elif price > 9_999_999:
                errors["price"] = "Price is unrealistically large."
        except ValueError:
            errors["price"] = "Price must be a valid number."

    if not image:
        errors["image"] = "Product image (URL or base64) is required."

    if errors:
        return jsonify({"errors": errors}), 422

    # ── Insert ────────────────────────────────────────────────────────────
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO products (name, description, price, image) VALUES (%s, %s, %s, %s)",
            (name, description, float(price_raw), image),
        )
        conn.commit()
        new_id = cursor.lastrowid
        cursor.close()
        conn.close()
        return jsonify({"message": "Product added successfully.", "id": new_id}), 201
    except mysql.connector.Error as e:
        return jsonify({"error": f"Database error: {str(e)}"}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)
