import { useState } from "react";
import AddProduct from "./components/AddProduct";
import ProductList from "./components/ProductList";
import "./App.css";

export default function App() {
  const [view, setView] = useState("list"); // "list" | "add"
  const [refresh, setRefresh] = useState(0);

  const handleAdded = () => {
    setRefresh((r) => r + 1);
    setView("list");
  };

  return (
    <div className="app">
      {/* ── Header ──────────────────────────────────── */}
      <header className="header">
        <div className="header-inner">
          <div className="brand">
            <span className="brand-icon">♚</span>
            <div>
              <span className="brand-name">Horlogerie.</span>
              <span className="brand-sub">Watch Catalog</span>
            </div>
          </div>

          <nav className="nav">
            <button
              className={`nav-btn ${view === "list" ? "active" : ""}`}
              onClick={() => setView("list")}
            >
              View All Products
            </button>
            <button
              className={`nav-btn ${view === "add" ? "active" : ""}`}
              onClick={() => setView("add")}
            >
              + Add Product
            </button>
          </nav>
        </div>
      </header>

      {/* ── Main ────────────────────────────────────── */}
      <main className="main">
        {view === "list" ? (
          <ProductList key={refresh} />
        ) : (
          <AddProduct onSuccess={handleAdded} onCancel={() => setView("list")} />
        )}
      </main>

      <footer className="footer">
        <span>© 2026 Horlogerie · Watch Catalog Application</span>
      </footer>
    </div>
  );
}
