import "./ProductCard.css";

// Highlights the matching prefix in the product name
function HighlightName({ name, query }) {
  if (!query) return <>{name}</>;
  const lower = name.toLowerCase();
  const q = query.toLowerCase();
  if (lower.startsWith(q)) {
    return (
      <>
        <mark className="highlight">{name.slice(0, q.length)}</mark>
        {name.slice(q.length)}
      </>
    );
  }
  return <>{name}</>;
}

export default function ProductCard({ product, highlight }) {
  const { name, description, price, image } = product;

  const formattedPrice = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(price);

  return (
    <article className="card">
      <div className="card-img-wrap">
        <img
          src={image}
          alt={name}
          className="card-img"
          onError={(e) => {
            e.target.src =
              "https://images.unsplash.com/photo-1509048191080-d2984bad6ae5?w=400&q=80";
          }}
        />
        <div className="card-img-overlay" />
      </div>

      <div className="card-body">
        <h2 className="card-name">
          <HighlightName name={name} query={highlight} />
        </h2>
        <p className="card-desc">{description}</p>
        <div className="card-footer">
          <span className="card-price">{formattedPrice}</span>
          <span className="card-badge">In Stock</span>
        </div>
      </div>
    </article>
  );
}
