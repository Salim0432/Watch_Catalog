import { useState, useEffect, useRef } from "react";
import ProductCard from "./ProductCard";
import "./ProductList.css";

const API = "http://localhost:5000/api/products";

export default function ProductList() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const debounceRef = useRef(null);

  // ── Fetch (used on mount and via jQuery-style debounce) ──
  const fetchProducts = (query = "") => {
    setLoading(true);
    setError("");

    // jQuery $.ajax equivalent using fetch
    const url = query ? `${API}?search=${encodeURIComponent(query)}` : API;

    // Using jQuery if available (loaded via CDN in index.html), otherwise fetch
    if (window.$ && window.$.ajax) {
      window.$.ajax({
        url,
        method: "GET",
        success: (data) => {
          setProducts(data.products || []);
          setLoading(false);
        },
        error: (xhr) => {
          setError("Failed to load products. Is the server running?");
          setLoading(false);
        },
      });
    } else {
      fetch(url)
        .then((r) => r.json())
        .then((data) => {
          setProducts(data.products || []);
          setLoading(false);
        })
        .catch(() => {
          setError("Failed to load products. Is the server running?");
          setLoading(false);
        });
    }
  };

  // Initial load
  useEffect(() => {
    fetchProducts();
  }, []);

  // Live search — fires on every keystroke (debounced 300 ms via jQuery/setTimeout)
  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearch(value);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      fetchProducts(value);
    }, 300);
  };

  return (
    <section className="product-list-section">
      {/* ── Page title ── */}
      <div className="list-header">
        <h1 className="list-title">
          <span className="list-title-serif">Our</span> Collection
        </h1>
        <p className="list-subtitle">
          {products.length} {products.length === 1 ? "timepiece" : "timepieces"} available
        </p>
      </div>

      {/* ── Search bar ── */}
      <div className="search-wrap">
        <span className="search-icon">⌕</span>
        <input
          id="search-input"
          className="search-input"
          type="text"
          placeholder="Search by name…"
          value={search}
          onChange={handleSearchChange}
          autoComplete="off"
        />
        {search && (
          <button
            className="search-clear"
            onClick={() => { setSearch(""); fetchProducts(""); }}
          >
            ✕
          </button>
        )}
      </div>

      {/* ── States ── */}
      {loading && (
        <div className="state-box">
          <div className="spinner" />
          <p>Loading collection…</p>
        </div>
      )}

      {error && !loading && (
        <div className="state-box error-box">
          <span className="state-icon">⚠</span>
          <p>{error}</p>
        </div>
      )}

      {!loading && !error && products.length === 0 && (
        <div className="state-box">
          <span className="state-icon">◈</span>
          <p>No products found{search ? ` for "${search}"` : ""}.</p>
        </div>
      )}

      {/* ── Grid ── */}
      {!loading && !error && products.length > 0 && (
        <div className="product-grid">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} highlight={search} />
          ))}
        </div>
      )}
    </section>
  );
}
