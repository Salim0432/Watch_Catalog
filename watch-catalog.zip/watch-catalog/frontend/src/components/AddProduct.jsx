import { useState } from "react";
import "./AddProduct.css";

const API = "http://localhost:5000/api/products";
const EMPTY = { name: "", description: "", price: "", image: "" };

export default function AddProduct({ onSuccess, onCancel }) {
  const [form, setForm] = useState(EMPTY);
  const [clientErrors, setClientErrors] = useState({});
  const [serverErrors, setServerErrors] = useState({});
  const [globalError, setGlobalError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [preview, setPreview] = useState("");

  // ── Helpers ──────────────────────────────────────────────
  const allErrors = { ...serverErrors, ...clientErrors };

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Product name is required.";
    else if (form.name.trim().length > 150) errs.name = "Max 150 characters.";

    if (!form.description.trim()) errs.description = "Description is required.";
    else if (form.description.trim().length > 1000) errs.description = "Max 1000 characters.";

    if (!form.price.toString().trim()) {
      errs.price = "Price is required.";
    } else {
      const n = parseFloat(form.price);
      if (isNaN(n) || n <= 0) errs.price = "Enter a valid positive price.";
    }

    if (!form.image.trim()) errs.image = "Image URL or base64 is required.";

    return errs;
  };

  // ── Handlers ─────────────────────────────────────────────
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setClientErrors((errs) => ({ ...errs, [name]: undefined }));
    setServerErrors((errs) => ({ ...errs, [name]: undefined }));
    if (name === "image") setPreview(value.trim());
  };

  // Handle image file upload → base64
  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setClientErrors((errs) => ({ ...errs, image: "Only image files are allowed." }));
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target.result;
      setForm((f) => ({ ...f, image: dataUrl }));
      setPreview(dataUrl);
      setClientErrors((errs) => ({ ...errs, image: undefined }));
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setClientErrors(errs);
      return;
    }

    setSubmitting(true);
    setGlobalError("");
    setServerErrors({});

    try {
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          description: form.description.trim(),
          price: parseFloat(form.price),
          image: form.image.trim(),
        }),
      });

      const data = await res.json();

      if (res.status === 201) {
        onSuccess();
      } else if (res.status === 422 && data.errors) {
        setServerErrors(data.errors);
      } else {
        setGlobalError(data.error || "An unexpected error occurred.");
      }
    } catch {
      setGlobalError("Cannot reach the server. Please check that Flask is running.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    setForm(EMPTY);
    setClientErrors({});
    setServerErrors({});
    setGlobalError("");
    setPreview("");
  };

  // ── Render ───────────────────────────────────────────────
  return (
    <section className="add-section">
      <div className="add-header">
        <h1 className="add-title">
          <span className="add-title-serif">Add</span> New Product
        </h1>
        <p className="add-subtitle">Fill in the details below to list a new timepiece.</p>
      </div>

      <div className="add-layout">
        {/* ── Form ── */}
        <div className="form-card">
          {globalError && (
            <div className="global-error">
              <span>⚠</span> {globalError}
            </div>
          )}

          {/* Name */}
          <div className={`field ${allErrors.name ? "has-error" : ""}`}>
            <label htmlFor="name">Product Name <span className="req">*</span></label>
            <input
              id="name"
              name="name"
              type="text"
              value={form.name}
              onChange={handleChange}
              placeholder="e.g. Chronos Elite"
              maxLength={150}
            />
            {allErrors.name && <span className="field-error">{allErrors.name}</span>}
            <span className="char-count">{form.name.length}/150</span>
          </div>

          {/* Description */}
          <div className={`field ${allErrors.description ? "has-error" : ""}`}>
            <label htmlFor="description">Description <span className="req">*</span></label>
            <textarea
              id="description"
              name="description"
              value={form.description}
              onChange={handleChange}
              placeholder="Describe the watch — movement, materials, features…"
              rows={4}
              maxLength={1000}
            />
            {allErrors.description && <span className="field-error">{allErrors.description}</span>}
            <span className="char-count">{form.description.length}/1000</span>
          </div>

          {/* Price */}
          <div className={`field ${allErrors.price ? "has-error" : ""}`}>
            <label htmlFor="price">Price (USD) <span className="req">*</span></label>
            <div className="input-prefix-wrap">
              <span className="input-prefix">$</span>
              <input
                id="price"
                name="price"
                type="number"
                min="0.01"
                step="0.01"
                value={form.price}
                onChange={handleChange}
                placeholder="0.00"
              />
            </div>
            {allErrors.price && <span className="field-error">{allErrors.price}</span>}
          </div>

          {/* Image */}
          <div className={`field ${allErrors.image ? "has-error" : ""}`}>
            <label htmlFor="image">Image <span className="req">*</span></label>
            <input
              id="image"
              name="image"
              type="text"
              value={form.image}
              onChange={handleChange}
              placeholder="https://… or upload a file below"
            />
            <span className="field-hint">Paste a URL or upload an image file.</span>
            <label className="file-upload-btn">
              📁 Choose File
              <input type="file" accept="image/*" onChange={handleFile} hidden />
            </label>
            {allErrors.image && <span className="field-error">{allErrors.image}</span>}
          </div>

          {/* Actions */}
          <div className="form-actions">
            <button className="btn-secondary" onClick={handleReset} disabled={submitting}>
              Reset
            </button>
            <button className="btn-secondary" onClick={onCancel} disabled={submitting}>
              Cancel
            </button>
            <button className="btn-primary" onClick={handleSubmit} disabled={submitting}>
              {submitting ? "Saving…" : "Add Product"}
            </button>
          </div>
        </div>

        {/* ── Preview ── */}
        <div className="preview-card">
          <p className="preview-label">Image Preview</p>
          {preview ? (
            <img src={preview} alt="preview" className="preview-img"
              onError={(e) => { e.target.style.display = "none"; }} />
          ) : (
            <div className="preview-placeholder">
              <span>◈</span>
              <p>Preview will appear here</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
